void sketchify();

int main()
{
    sketchify();
}
